package net.nend;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import net.nend.android.NendAdIconLayout;
import net.nend.android.NendAdIconLoader;
import net.nend.android.NendAdIconLoader.OnClickListener;
import net.nend.android.NendAdIconLoader.OnInformationClickListener;
import net.nend.android.NendAdIconLoader.OnFailedListener;
import net.nend.android.NendAdIconLoader.OnReceiveListener;
import net.nend.android.NendAdIconView;
import net.nend.android.NendIconError;

import org.appcelerator.kroll.KrollDict;
import org.appcelerator.titanium.proxy.TiViewProxy;
import org.appcelerator.titanium.view.TiUIView;
import org.appcelerator.titanium.util.TiConvert;

/**
 * Icon型広告をセットで作成するViewクラス
 * 
 * @author e_yokoi
 *
 */
public class NendIconsView extends TiUIView {
    
    private TiViewProxy mProxy;
    
    /** Icon用Loader */
    private NendAdIconLoader mLoader;
   
    /** 最大表示個数（配置領域のサイズにも依存するためmodule側で制御） */
    private static final int ICON_COUNT_DEFAULT = 1;
    private static final int ICON_COUNT_MAX = 6;
    
    /** デフォルトアイコンサイズ */
    private static final int ICON_SIZE = 75;
    
    /**
     * NendIconsView コンストラクタ
     * 
     * @param proxy
     * @param spotId
     * @param apiKey
     * @param orientation - 並列配置方向、水平or垂直
     * @param textHidden - テキスト非表示 (※iOS側に合わせています)
     * @param textColor - テキスト色指定 (※iOS側に合わせています)
     */

    public NendIconsView(TiViewProxy proxy, float viewWidth, float viewHeight, int spotId, String apiKey, String orientation, boolean textHidden, String textColor, int iconCount, boolean spaceEnabled) {
        super(proxy);
        mProxy = proxy;
        
        // 画面密度取得
        DisplayMetrics metrics = new DisplayMetrics();
        ((WindowManager)proxy.getActivity().getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getMetrics(metrics);        

    	LinearLayout layout = new LinearLayout(proxy.getActivity());
    	layout.setGravity(Gravity.CENTER);

        if(iconCount <= 0){
        	iconCount = ICON_COUNT_DEFAULT;
        }
        else if(iconCount > ICON_COUNT_MAX){
        	iconCount = ICON_COUNT_MAX;
        }

        //アイコンのサイズを決定する
    	float iconSize;    	
    	if(viewWidth == 0 && viewHeight == 0){
    		iconSize = ICON_SIZE; 
    	}
    	    	
    	if(orientation.equalsIgnoreCase("vertical")) {
    		iconSize = Math.min(viewWidth,(viewHeight /iconCount));
            layout.setOrientation(NendAdIconLayout.VERTICAL);	
        } else {
    		iconSize = Math.min((viewWidth/iconCount),viewHeight);
            layout.setOrientation(NendAdIconLayout.HORIZONTAL);
        }

    	//余白なし＆テキストありの場合、viewから見切れるため サイズを調整する
    	if(!spaceEnabled && !textHidden){
    		iconSize = ((iconSize * 57) / 75);
    	}

        // NendAdIconView内で画面密度を考慮して描画を行っているため、ピクセルでIconViewを生成する
        float density = metrics.density;
    	LinearLayout.LayoutParams params = new LinearLayout.LayoutParams((int)(iconSize*density), (int)(iconSize*density));

        if(textColor.equals("")){
            textColor = "#000000";
        }
        
        // アイコン広告生成
        mLoader = new NendAdIconLoader(proxy.getActivity(), spotId, apiKey);

        for (int i = 0; i < iconCount; i++) {
            NendAdIconView iconView = new NendAdIconView(proxy.getActivity());
            iconView.setTitleVisible(!(textHidden));
            iconView.setTitleColor(TiConvert.toColor(textColor));
            iconView.setLayoutParams(params);
            iconView.setIconSpaceEnabled(spaceEnabled);
            mLoader.addIconView(iconView);
            layout.addView(iconView);
        }
        mLoader.loadAd();
        mLoader.setOnClickListener(onClickListener);
        mLoader.setOnInformationClickListener(onInformationClickListener);
        mLoader.setOnFailedListener(onFailedListener);
        mLoader.setOnReceiveListener(onReceiveListener);
        
        // レイアウトを返却
        setNativeView(layout);
    }

    @Override
    public void processProperties(KrollDict d) {
        super.processProperties(d);
    }
    
//    // 復帰通知
//    @Override
//    public void onDismissScreen(NendAdIconView view) {
//    }
    
	private OnClickListener onClickListener = new OnClickListener() {		
		public void onClick(NendAdIconView iconView) {
			mProxy.fireEvent("click", "");
		};
	};
	private OnInformationClickListener onInformationClickListener = new OnInformationClickListener() {		
		public void onClickInformation(NendAdIconView iconView) {
			mProxy.fireEvent("information", "");
		};
	};
	private OnFailedListener onFailedListener = new OnFailedListener() {
		public void onFailedToReceiveAd(NendIconError error) {
	        mProxy.fireEvent("error", "");
		}
	};
	private OnReceiveListener onReceiveListener = new OnReceiveListener() {
		public void onReceiveAd(NendAdIconView iconView) {
	        mProxy.fireEvent("receive", "");
		}
	};

    /** 広告リロード停止 **/
    public void pause(){
    	mLoader.pause();
    }
    
    /** 広告リロード再開 **/
    public void resume(){
    	mLoader.resume();
    }
}