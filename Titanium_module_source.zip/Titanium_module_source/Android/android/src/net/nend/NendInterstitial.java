package net.nend;

import net.nend.android.NendAdInterstitial;
import net.nend.android.NendAdInterstitial.NendAdInterstitialClickType;
import net.nend.android.NendAdInterstitial.NendAdInterstitialShowResult;
import net.nend.android.NendAdInterstitial.NendAdInterstitialStatusCode;

import org.appcelerator.kroll.KrollDict;
import org.appcelerator.titanium.TiApplication;

import android.app.Activity;

public class NendInterstitial {

	private static NendModule nendModule;
    
	public static NendAdInterstitial.OnClickListener setOnClickListener(){	
		NendAdInterstitial.OnClickListener listener = new NendAdInterstitial.OnClickListener() {
			
			public void onClick(NendAdInterstitialClickType clickType) {
				int resultCode = clickType.ordinal();
		        KrollDict event = new KrollDict();
		        event.put("resultCode", resultCode);
		        if(nendModule != null){
					nendModule.fireEvent("interstitialClick", event);
		        }
			}
		};
		return listener;
	}

	public static NendAdInterstitial.OnClickListener setOnClickListenerWithSpotId(){
		
		NendAdInterstitial.OnClickListener listener = new NendAdInterstitial.OnClickListenerSpot() {
			
			public void onClick(NendAdInterstitialClickType clickType) {

			}
			
			public void onClick(NendAdInterstitialClickType clickType, int spotId) {
				int resultCode = clickType.ordinal();
		        KrollDict event = new KrollDict();
		        event.put("resultCode", resultCode);
		        if(nendModule != null){
					nendModule.fireEvent("interstitialClick", event);
		        }
			}
		};
		return listener;
	}

	public static void createInterstitialAd( final String apiKey, final String spotID){
		
		TiApplication appContext = TiApplication.getInstance();
		final Activity activity = appContext.getCurrentActivity();

		activity.runOnUiThread(new Runnable() {
			public void run() {
				int intSpotID = Integer.parseInt(spotID);
				
				NendAdInterstitial.OnCompletionListener listenerWithSpotId = new NendAdInterstitial.OnCompletionListenerSpot() {
					
					public void onCompletion(NendAdInterstitialStatusCode statusCode) {

					}
					public void onCompletion(NendAdInterstitialStatusCode statusCode, int spotId) {
						int resultCode = statusCode.ordinal();
				        KrollDict event = new KrollDict();
				        event.put("resultCode", resultCode);
				        if(nendModule != null){
							nendModule.fireEvent("interstitialLoadResult", event);
				        }
					}
				};
				NendAdInterstitial.setListener(listenerWithSpotId);
				
				NendAdInterstitial.loadAd(activity, apiKey, intSpotID);
			}
		});
	}

	public static void showInterstitial(final String spotID){
		TiApplication appContext = TiApplication.getInstance();
		final Activity activity = appContext.getCurrentActivity();
		activity.runOnUiThread(new Runnable() {
			public void run() {
				if (spotID == null){
					NendAdInterstitial.OnClickListener listener = setOnClickListener();
					resultOfShowAd(activity, listener);
				}else{
					NendAdInterstitial.OnClickListener listener = setOnClickListenerWithSpotId();
					resultOfShowAdWithSpotId(activity, spotID, listener);
				}
			}
		});
	}
	
	public static void createInterstitial(NendModule module, final String apiKey, final String spotID) {
		nendModule = module;
		createInterstitialAd(apiKey, spotID);
	}
	
	public static void showInterstitialView() {
		showInterstitial(null);
	}
	
	public static void showInterstitialView(final String spotID) {		
		showInterstitial(spotID);
	}

	public static void dismissInterstitialView(){
		TiApplication appContext = TiApplication.getInstance();
		final Activity activity = appContext.getCurrentActivity();
		activity.runOnUiThread(new Runnable() {
			public void run() {
				boolean dismissResult = NendAdInterstitial.dismissAd();
                // 広告削除結果で何かの処理する場合
				if (dismissResult){
				}
			}
		});
	}
	
	public static void resultOfShowAd(Activity activity, NendAdInterstitial.OnClickListener listener){
        // 表示結果が返却される				
        NendAdInterstitialShowResult result = NendAdInterstitial.showAd(activity, listener);
        fireShowResult(result);
	}
	
	public static void resultOfShowAdWithSpotId(Activity activity, final String spotID, NendAdInterstitial.OnClickListener listener){
        // 表示結果が返却される			
		int intSpotId = Integer.parseInt(spotID);
        NendAdInterstitialShowResult result = NendAdInterstitial.showAd(activity, intSpotId, listener);
        fireShowResult(result);
	}
	
	private static void fireShowResult(NendAdInterstitialShowResult result){
        int resultCode = result.ordinal();
        KrollDict event = new KrollDict();
        event.put("resultCode", resultCode);//読み取りデータ. e.bt_read_data
        if(nendModule != null){
    		nendModule.fireEvent("interstitialShowResult", event);
    	}
	}
}
