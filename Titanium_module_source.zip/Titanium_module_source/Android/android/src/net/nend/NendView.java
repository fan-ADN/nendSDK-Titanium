package net.nend;

import net.nend.android.NendAdListener;
import net.nend.android.NendAdInformationListener;
import net.nend.android.NendAdView;

import org.appcelerator.kroll.KrollDict;
import org.appcelerator.titanium.proxy.TiViewProxy;
import org.appcelerator.titanium.view.TiUIView;

import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;

public class NendView extends TiUIView implements NendAdListener, NendAdInformationListener {
    
    private TiViewProxy mProxy;
    private NendAdView mNendAdView;

    public NendView(TiViewProxy proxy, int spotId, String apiKey, boolean isAdjust) {
        super(proxy);
        mProxy = proxy;
        
        //setNativeViewに一つレイアウトを挟まないと画面いっぱいに表示されてしまう
        LinearLayout baseLayout = new LinearLayout(proxy.getActivity());
        
		WindowManager.LayoutParams LayoutParams = new WindowManager.LayoutParams();
		LayoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_PANEL;
		LayoutParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
		LayoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT;
		LayoutParams.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
		LayoutParams.gravity = Gravity.CENTER | Gravity.CENTER;
		LayoutParams.format = PixelFormat.TRANSLUCENT;
        
        mNendAdView = new NendAdView(proxy.getActivity(), spotId, apiKey, isAdjust);
        mNendAdView.setListener(this);
        mNendAdView.loadAd();
        
        baseLayout.addView(mNendAdView, LayoutParams);
        
        setNativeView(baseLayout);
    }
    
    @Override
    public void processProperties(KrollDict d) {
        super.processProperties(d);
    }
    
    // 復帰通知
    public void onDismissScreen(NendAdView view) {
    }
    
    /** クリック通知 **/
    public void onClick(NendAdView view) {
        mProxy.fireEvent("click", "");
    }

    /** インフォメーションボタンクリック通知 **/
    public void onInformationButtonClick(NendAdView view) {
        mProxy.fireEvent("information", "");
    }

    /** 受信エラー通知 **/
    public void onFailedToReceiveAd(NendAdView view) {
        mProxy.fireEvent("error", "");
    }
    
    /** 受信成功通知 **/
    public void onReceiveAd(NendAdView view) {
        mProxy.fireEvent("receive", "");
    }
    
    /** 広告リロード停止 **/
    public void pause(){
        mNendAdView.pause();
    }
    
    /** 広告リロード再開 **/
    public void resume(){
        mNendAdView.resume();
    }
}