# Nend_iOS Module

## Description

nend module for iOS

## Accessing the Nend_iOS Module

To access this module from JavaScript, you would do the following:

	var Nend_iOS = require("net.nend");

The Nend_iOS variable is a reference to the Module object.	