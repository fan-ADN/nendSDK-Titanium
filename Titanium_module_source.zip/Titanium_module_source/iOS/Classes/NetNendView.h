//
//  NetNendView.h
//  Nend_iOS
//
//  Copyright (c) 2015年 F@N Communications, Inc. All rights reserved.
//
//

#import "TiUIView.h"
#import "NADView.h"

@interface NetNendView : TiUIView<NADViewDelegate> {
    NADView * nadView;
}

-(void)pause;
-(void)resume;

@end
