//
//  NetNendInterstitial.m
//  Nend_iOS
//
//  Copyright (c) 2015年 F@N Communications, Inc. All rights reserved.
//
//

#import "NetNendInterstitial.h"
#import "TiApp.h"

@implementation NetNendInterstitial

+ (instancetype) sharedInstance
{
    static NetNendInterstitial* instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[NetNendInterstitial alloc] init];
    });
    return instance;
}

- (instancetype) init
{
    self = [super init];
    if ( self )
    {
        [NADInterstitial sharedInstance].isOutputLog = NO;
        [NADInterstitial sharedInstance].delegate = self;
    }
    return self;
}


-(void)createInterstitialAd:(NetNendModule*)module apiKey:(NSString*)apiKey spotId:(NSString*)spotId{
    self.nendModule = module;
    [[NADInterstitial sharedInstance] loadAdWithApiKey:apiKey spotId:spotId];
}

-(void)showInterstitialView{
    NADInterstitialShowResult result;
    //Interstitialの表示はメインスレッドで行うこと
    dispatch_async(dispatch_get_main_queue(), ^{
        NADInterstitialShowResult result =[[NADInterstitial sharedInstance] showAdFromViewController:[TiApp app].controller];
        id args = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",result],@"resultCode",nil];
        if (self.nendModule) {
            [self.nendModule fireEvent:@"interstitialShowResult" withObject:args];
        }
    });
}

-(void)showInterstitialView:(NSString*)spotID{
    NADInterstitialShowResult result;
    //Interstitialの表示はメインスレッドで行うこと
    dispatch_async(dispatch_get_main_queue(), ^{
        NADInterstitialShowResult result =[[NADInterstitial sharedInstance] showAdFromViewController:[TiApp app].controller spotId:spotID];
        id args = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",result],@"resultCode",nil];
        if (self.nendModule) {
            [self.nendModule fireEvent:@"interstitialShowResult" withObject:args];
        }
    });
}

-(void)dismissInterstitialView{
    dispatch_async(dispatch_get_main_queue(), ^{
        BOOL returnCode = [[NADInterstitial sharedInstance] dismissAd];
    });
}

//- (void) didFinishLoadInterstitialAdWithStatus:(NADInterstitialStatusCode)status
//{
////    NSLog(@"[INFO] didFinishLoadInterstitialAdWithStatus status = %d",status);
//    id args = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",status],@"resultCode",nil];
//    [nendModule fireEvent:@"interstitialLoadResult" withObject:args];
//}

- (void) didFinishLoadInterstitialAdWithStatus:(NADInterstitialStatusCode)status spotId:(NSString *)spotId
{
//    NSLog(@"[INFO] didFinishLoadInterstitialAdWithStatus status = %d",status);
    id args = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",status],@"resultCode",nil];
    if (self.nendModule) {
        [self.nendModule fireEvent:@"interstitialLoadResult" withObject:args];
    }
}

//- (void) didClickWithType:(NADInterstitialClickType)type
//{
////    NSLog(@"[INFO] didClickWithType type = %d",type);
//    id args = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",type],@"resultCode",nil];
//    [nendModule fireEvent:@"interstitialClick" withObject:args];
//}

- (void) didClickWithType:(NADInterstitialClickType)type spotId:(NSString *)spotId
{
//    NSLog(@"[INFO] didClickWithType type = %d",type);
    id args = [NSDictionary dictionaryWithObjectsAndKeys:[NSString stringWithFormat:@"%d",type],@"resultCode",nil];
    if (self.nendModule) {
        [self.nendModule fireEvent:@"interstitialClick" withObject:args];
    }
}

@end
