//
//  NetNendInterstitial.h
//  Nend_iOS
//
//  Copyright (c) 2015年 F@N Communications, Inc. All rights reserved.
//
//

#import <Foundation/Foundation.h>
#import "NADInterstitial.h"
#import "NetNendModule.h"

@interface NetNendInterstitial : NSObject<NADInterstitialDelegate>

+(instancetype)sharedInstance;
-(void)createInterstitialAd:(NetNendModule*)module apiKey:(NSString*)apiKey spotId:(NSString*)spotId;
-(void)showInterstitialView;
-(void)showInterstitialView:(NSString*)spotID;
-(void)dismissInterstitialView;

@property(nonatomic,retain)NetNendModule* nendModule;


@end
