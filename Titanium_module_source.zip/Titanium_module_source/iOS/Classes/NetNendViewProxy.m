//
//  NetNendViewProxy.m
//  Nend_iOS
//
//  Copyright (c) 2015年 F@N Communications, Inc. All rights reserved.
//
//

#import "NetNendViewProxy.h"
#import "NetNendView.h"

@implementation NetNendViewProxy

-(void)pause:(id)args
{
    [[self view] performSelectorOnMainThread:@selector(pause)
                                  withObject:nil waitUntilDone:NO];
}

-(void)resume:(id)args
{
    [[self view] performSelectorOnMainThread:@selector(resume)
                                  withObject:nil waitUntilDone:NO];
}

@end
