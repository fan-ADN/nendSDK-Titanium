//
//  NetNendView.m
//  Nend_iOS
//
//  Copyright (c) 2015年 F@N Communications, Inc. All rights reserved.
//
//

#import "NetNendView.h"

// IconView Setting Defaults.

@implementation NetNendView

#pragma mark - NADView

-(id)init{
    self = [super init];

    if (self) {
        //viewのframe補正を受信する
        [self addObserver:self forKeyPath:@"frame" options:NSKeyValueObservingOptionNew context:nil];
        [self addObserver:self forKeyPath:@"center" options:NSKeyValueObservingOptionNew context:nil];
        [self addObserver:self forKeyPath:@"bounds" options:NSKeyValueObservingOptionNew context:nil];
    }

    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    if (nadView == nil)
    {
        self.frame = CGRectZero;
        self.backgroundColor = [UIColor clearColor];
        BOOL isAdjust = NO;
        if([self.proxy valueForKey:@"isAdjust"] != nil)
        {
            isAdjust = [TiUtils boolValue:[self.proxy valueForKey:@"isAdjust"]];
        }
        
        nadView = [[NADView alloc]  initWithFrame:CGRectMake(0, 0, 320, 50) isAdjustAdSize:isAdjust];
        [nadView setNendID:[self.proxy valueForKey:@"apiKey"] spotID:[TiUtils stringValue:[self.proxy valueForKey:@"spotId"]]];
        [nadView setDelegate:self];
        [nadView load];
        [self addSubview:nadView];
        [self bringSubviewToFront:nadView];
        
    }
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    // autoResizingMaskが効かないので手動で位置調整をおこなう
    [super setFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    [self setNadviewFrame];
}

-(void)dealloc
{
    nadView.delegate = nil;
    RELEASE_TO_NIL(nadView);
    
    [self removeObserver:self forKeyPath:@"frame"];
    [self removeObserver:self forKeyPath:@"center"];
    [self removeObserver:self forKeyPath:@"bounds"];
    
    [super dealloc];
}

-(void)frameSizeChanged:(CGRect)frame bounds:(CGRect)bounds{
    [self setNadviewFrame];
}

#pragma mark - NADView, NADIconLoader 共通メソッド

/** 広告リロード停止 **/
-(void)pause
{
    [nadView pause];
}

/** 広告リロード再開 **/
-(void)resume
{
    [nadView resume];
}

#pragma mark - NADViewDelegate

/** ロード完了通知 **/
- (void)nadViewDidFinishLoad:(NADView *)adView
{
    [self setNadviewFrame];
}

-(void)setNadviewFrame{
    if (nadView) {
        //中央を保持しておく
        CGPoint pointCenter = [self.superview center];
        
        //サイズ補正
        float newX, newY;
        
        //位置補正
        if ([self.proxy valueForKey:@"left"] != nil) {
            newX = [[self.proxy valueForKey:@"left"] floatValue];
        }
        else if ([self.proxy valueForKey:@"right"] != nil) {
            newX = self.superview.frame.size.width - [[self.proxy valueForKey:@"right"] floatValue] - nadView.frame.size.width;
        }
        else {
            newX = pointCenter.x - (nadView.frame.size.width / 2);
        }
        
        if ([self.proxy valueForKey:@"top"] != nil) {
            newY = [[self.proxy valueForKey:@"top"] floatValue];
        }
        else if ([self.proxy valueForKey:@"bottom"] != nil) {
            newY = self.superview.frame.size.height - [[self.proxy valueForKey:@"bottom"] floatValue] - nadView.frame.size.height;
        }
        else {
            newY = pointCenter.y - (nadView.frame.size.height / 2);
        }

        [nadView setFrame:CGRectMake(newX, newY, nadView.frame.size.width, nadView.frame.size.height)];

    }
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView* view = [super hitTest:point withEvent:event];
    
    if (view == self) {
        return nil;
    }
    return view;
}

/** 受信成功通知 **/
-(void)nadViewDidReceiveAd:(NADView *)adView
{
    [self.proxy fireEvent:@"receive"];
}

/** 受信エラー通知 **/
-(void)nadViewDidFailToReceiveAd:(NADView *)adView
{
    [self.proxy fireEvent:@"error"];
}

/** クリック通知 **/
- (void) nadViewDidClickAd:(NADView *)adView
{
    [self.proxy fireEvent:@"click"];
}

/** インフォメーションボタンクリック通知 **/
- (void) nadViewDidClickInformation:(NADView *)adView
{
    [self.proxy fireEvent:@"information"];
}

@end
