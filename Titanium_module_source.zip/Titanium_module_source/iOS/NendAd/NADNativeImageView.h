//
//  NADNativeImageView.h
//  NendAd
//
//  Copyright (c) 2015年 F@N Communications, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NADNativeImageView : UIImageView

@end
